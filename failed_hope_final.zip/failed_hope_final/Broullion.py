import sys
import pygame
import time

# Initialize pygame
pygame.init()

# Set up the screen
screen_width = 1280
screen_height = 720
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("GameTest.py")

# Load and scale the background image
background_image = pygame.image.load("/Users/anischedouba/Desktop/GameDev/failed_hopePy/startingPoint.png")
background_image = pygame.transform.scale(background_image, (screen_width, screen_height))

# Set up the font
font = pygame.font.Font(None, 24)

# Set up the text area
text_area_color = (0, 0, 0)
text_area_height = 140
text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

# Set up the dialogue text
current_text = ""

def update_text(new_text):
    global current_text
    current_text = new_text

def display_text():
    screen.blit(background_image, (0, 0))
    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
    screen.fill(text_area_color, text_area_rect)

    dialogue_text = font.render(current_text, True, (255, 255, 255))
    dialogue_rect = dialogue_text.get_rect(midleft=text_area_rect.midleft)
    screen.blit(dialogue_text, dialogue_rect)

    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False

def wait_for_click():
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Draw everything
    screen.blit(background_image, (0, 0))
    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
    screen.fill(text_area_color, text_area_rect)

    # Display the text
    update_text("> …")
    display_text()
    wait_for_click()

    update_text("> Le joueur émerge du bâtiment, le souffle court, prêt à affronter l'inconnu qui s'étend devant lui.")
    display_text()
    wait_for_click()

    update_text("> Autour de lui, la ville semble endormie, ses rues désertes témoignant du mystère qui l'entoure.")
    display_text()
    wait_for_click()
    
    update_text("> Dans ca main se trouve une photo, inscrit une adresse inconnu.")
    display_text()
    wait_for_click()

    update_text("> Son subconscient murmure, un flux constant de suggestions qui dansent dans les recoins de son esprit, offrant des conseils sur les chemins à prendre.")
    display_text()
    wait_for_click()

    update_text("> Le narrateur observe silencieusement, attendant de voir quel choix le joueur fera, quelle voie il décidera d'explorer dans cette histoire en devenir.")
    display_text()
    wait_for_click()

    update_text("> Quel chemin choisira le joueur ?")
    display_text()
    wait_for_click()

    update_text("")
    display_text()
    # Set up the choice buttons
    button_font = pygame.font.Font(None, 24)
    button_width = 600
    button_height = 30
    button_margin = 10
    button_color = (255, 255, 255)
    button_text_color = (0, 0, 0)

    choices = [
    {"text": "1 - Se rendre à la supérette la plus proche pour se réapprovisionner.", "rect": pygame.Rect(20, 570, button_width, button_height)},
    {"text": "2 - Suivre directement l'adresse inscrite sur la photo, bravant l'inconnu.", "rect": pygame.Rect(20, 610, button_width, button_height)},
    {"text": "3 - Parcourir les rues à la recherche d'un endroit sûr où se réfugier.", "rect": pygame.Rect(20, 650, button_width, button_height)},
    ]

    def display_choices():
        for choice in choices:
            pygame.draw.rect(screen, button_color, choice["rect"])
            button_text = button_font.render(choice["text"], True, button_text_color)
            screen.blit(button_text, (choice["rect"].x + 10, choice["rect"].y + 5))
        pygame.display.flip()

    display_choices()

    # Wait for the player to click on a choice
    choice_selected = None
    while choice_selected is None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for choice in choices:
                    if choice["rect"].collidepoint(event.pos):
                        choice_selected = choice["text"]
                        break

    print("Le joueur a choisi :", choice_selected)

# ...
# Update the display
    pygame.display.flip()

# Quit pygame
    pygame.quit()