import sys
import pygame
import time

# Initialize pygame
pygame.init()

# Set up the screen
screen_width = 1280
screen_height = 720
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("GameTest.py")

# Load and scale the background image
background_image = pygame.image.load("/Users/anischedouba/Desktop/GameDev/failed_hopePy/startingPoint.png")
background_image = pygame.transform.scale(background_image, (screen_width, screen_height))

# Set up the font
font = pygame.font.Font(None, 24)

# Set up the text area
text_area_color = (0, 0, 0)
text_area_height = 140
text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

# Set up the dialogue text
current_text = ""

def update_text(new_text):
    global current_text
    current_text = new_text

def display_text():
    screen.blit(background_image, (0, 0))
    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
    screen.fill(text_area_color, text_area_rect)

    x, y = text_area_rect.midleft
    for char in current_text:
        dialogue_text = font.render(char, True, (255, 255, 255))
        screen.blit(dialogue_text, (x, y))
        x += dialogue_text.get_width()
        pygame.display.flip()
        time.sleep(0.05)

    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False

def wait_for_click():
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Draw everything
    screen.blit(background_image, (0, 0))
    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
    screen.fill(text_area_color, text_area_rect)

    # Display the text
    update_text("> …")
    display_text()
    wait_for_click()

    update_text("> Le joueur émerge du bâtiment, le souffle court, prêt à affronter l'inconnu qui s'étend devant lui.")
    display_text()
    wait_for_click()

    update_text("> Autour de lui, la ville semble endormie, ses rues désertes témoignant du mystère qui l'entoure.")
    display_text()
    wait_for_click()

    update_text("> Soudain, des créatures sans visage surgissent de l'ombre, encerclant le joueur avec des mouvements inquiétants.")
    display_text()
    wait_for_click()

    update_text("> Créature 1: un murmure inhumain Nous t'avons trouvé.")
    display_text()
    wait_for_click()

    update_text("> Toi: reculant, le cœur battant Non, non, laissez-moi tranquille !")
    display_text()
    wait_for_click()

    # Update the display
    pygame.display.flip()

# Quit pygame
pygame.quit()