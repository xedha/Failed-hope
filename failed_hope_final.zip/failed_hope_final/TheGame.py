import sys
import pygame
import time

# Initialize pygame
pygame.init()
music_file = "start.mp3"
pygame.mixer.music.load(music_file)
pygame.mixer.music.set_volume(0.8)

# Set up the screen
screen_width = 1280
screen_height = 720
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("GameTest.py")

# Load and scale the background image
background_image = pygame.image.load("startingPoint.png")
background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


# Set up the font
font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

# Set up the text area
text_area_color = (0, 0, 0)
text_area_height = 140
text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

# Set up the dialogue text
current_text = ""

# Function to display text letter by letter
def display_text(text, font, surface, pos, color=(255, 255, 255), delay=50):
    global current_text
    current_text = "start"
    x, y = text_area_rect.midleft
    for char in current_text:
        current_text = font.render(char, True, (255, 255, 255))
        screen.blit(current_text, (x, y))
        x += current_text.get_width()
        pygame.display.flip()


def c3():

        update_text("> Le joueur, décidant de chercher un refuge sûr, s'éloigne prudemment des rues principales, espérant trouver un endroit où se cacher.")
        display_text()
        wait_for_click()

        update_text("> Mais alors qu'il pense être à l'abri, il entend des chuchotements sinistres dans l'obscurité")
        display_text()
        wait_for_click()
    
        update_text("> Toi : regardant autour de lui avec anxiété Je dois trouver un endroit pour me cacher, vite.")
        display_text()
        wait_for_click()

        update_text("> Soudain, des créatures sans visage surgissent de l'ombre, encerclant le joueur avec des mouvements inquiétants.")
        display_text()
        wait_for_click()

        update_text("> Créature 1: un murmure inhumain Nous t'avons trouvé.")
        display_text()
        wait_for_click()

        update_text("> Toi: reculant, le cœur battant Non, non, laissez-moi tranquille !")
        display_text()
        wait_for_click()

        update_text("> Les créatures avancent lentement vers toi, leurs silhouettes se mouvant de manière chaotique dans la pénombre.")
        display_text()
        wait_for_click()

        update_text("> Toi: paniqué Qu'est-ce que vous voulez de moi ?")
        display_text()
        wait_for_click()

        update_text("> Les créatures se jettent sur le joueur dans un assaut brutal, le plongeant dans l'obscurité sans fin")
        display_text()
        wait_for_click()

        update_text("> Le joueur est submergé par les ténèbres, sa présence s'effaçant dans le néant.")
        display_text()
        wait_for_click()


def SalleDangerTaro():
        update_text("> Joueur : observant les urnes avec méfiance Qu'est-ce que c'est que ça ?")
        display_text()
        wait_for_click()

        update_text("> Taro : s'approchant des urnes Aucune idée. Mais ça n'a pas l'air naturel.")
        display_text()
        wait_for_click()

        update_text("> Le joueur, curieux, remarque un journal posé sur une table. Il commence à le feuilleter, Taro jetant des coups d'œil par-dessus son épaule.")
        display_text()
        wait_for_click()

        update_text("> Joueur : lisant à haute voix 'Mon mari et moi avançons très vite sur le projet, les homonculus sont quasi autonomes, l'assignation de tâches sera bientôt possible.'")
        display_text()
        wait_for_click()

        update_text("> Taro : fronçant les sourcils Des homonculus ? Ça expliquerait les créatures sans visage qu'on a vues.")
        display_text()
        wait_for_click()

        update_text("> Le joueur continue de lire, chaque page révélant un peu plus du mystère.")
        display_text()
        wait_for_click()

        update_text("> Joueur : 'Les homonculus sont enfin fonctionnels, ils commenceront à opérer dès demain dans l'usine. Mon mari et moi sommes très satisfaits du résultat.'")
        display_text()
        wait_for_click()

        update_text("> Taro : hochant la tête Ça devient de plus en plus étrange. Continuons.")
        display_text()
        wait_for_click()

        update_text("> Joueur : feuilletant la page suivante 'Les homonculus ont été déployés dans toute la ville. C'est dommage qu'il ne soit pas là pour voir le fruit de nos efforts.'")
        display_text()
        wait_for_click()

        update_text("> Joueur : lisant la dernière page intacte 'J'ai commencé des travaux sur l'implémentation de sentiments aux homonculus, j'espère que ça se concrétisera bientôt.'")
        display_text()
        wait_for_click()

        update_text("> Le reste du journal est déchiré, rendant la lecture impossible. Cependant, à la fin du journal, une photo d'une femme reste intacte. Au verso, le nom 'Samantha' est écrit.")
        display_text()
        wait_for_click()

        update_text("> Taro : regardant la photo Samantha... Elle doit être impliquée dans tout ça.")
        display_text()
        wait_for_click()

        update_text("> Joueur : réfléchissant Oui, mais comment ?")
        display_text()
        wait_for_click()

        update_text("> Ils continuent leur exploration, avançant prudemment à travers le laboratoire jusqu'à ce qu'ils se retrouvent face à une énorme machine. À leur grande surprise, le nom du joueur est inscrit dessus.")
        display_text()
        wait_for_click()

        update_text("> Joueur : ébahi Mon nom ? Qu'est-ce que ça signifie ?")
        display_text()
        wait_for_click()

        update_text("> Taro : surpris C'est ton nom ? On dirait que cette machine a quelque chose à voir avec toi.")
        display_text()
        wait_for_click()

        update_text("> Le subconscient du joueur s'agite, des fragments de souvenirs tentant de se frayer un chemin à travers l'obscurité de l'amnésie.")
        display_text()
        wait_for_click()

def SalleDANGER():
        update_text("> Joueur : regardant autour de lui Où suis-je ?")
        display_text()
        wait_for_click()

        update_text("> En explorant la pièce, il remarque plusieurs urnes contenant des liquides noirs. Son attention est attirée par un bureau encombré de papiers.")
        display_text()
        wait_for_click()

        update_text("> En fouillant, il trouve un bout de papier déchiré provenant probablement d'un cahier.")
        display_text()
        wait_for_click()

        update_text("> Joueur : lisant le bout de papier 'Mon mari et moi avançons très vite sur le projet, les homonculus sont quasi autonomes, l'assignation de tâches sera bientôt possible.'")
        display_text()
        wait_for_click()

        update_text("> Intrigué, le joueur continue son exploration, découvrant d'autres pages du journal éparpillées sur le bureau.")
        display_text()
        wait_for_click()

        update_text("> Joueur : lisant la deuxième page 'Les homonculus sont enfin fonctionnels, ils commenceront à opérer dès demain dans l'usine. Mon mari et moi sommes très satisfaits du résultat.'")
        display_text()
        wait_for_click()

        update_text("> Joueur : feuilletant la troisième page 'Les homonculus ont été déployés dans toute la ville. C'est dommage qu'il ne soit pas là pour voir le fruit de nos efforts.'")
        display_text()
        wait_for_click()

        update_text("> Joueur : s'arrêtant sur la dernière page lisible 'J'ai commencé des travaux sur l'implémentation de sentiments aux homonculus, j'espère que ça se concrétisera bientôt.'")
        display_text()
        wait_for_click()

        update_text("> Le reste du journal est déchiré, rendant la lecture impossible. Cependant, une moitié de photo d'une femme reste intacte à la fin du journal.")
        display_text()
        wait_for_click()

        update_text("> Au verso, le nom 'Samantha' est écrit.")
        display_text()
        wait_for_click()

        update_text("> Joueur : regardant la photo Samantha... Qui est-elle ?")
        display_text()
        wait_for_click()

        update_text("> En avançant plus loin dans le laboratoire, le joueur découvre une énorme machine.")
        display_text()
        wait_for_click()

        update_text("> Il trouva un nom inscrit dessus, malgré son amnésie il le connaissait très bien, car ce nom n’était nul autre que le sien.")
        display_text()
        wait_for_click()

        update_text("> Joueur : ébahi Mon nom ? Qu'est-ce que tout cela signifie ?")
        display_text()
        wait_for_click()

        update_text("> Le subconscient du joueur s'agite, des fragments de souvenirs tentant de remonter à la surface.")
        display_text()
        wait_for_click()

        update_text("> La vérité semble proche, mais encore hors de portée.")
        display_text()
        wait_for_click()

        update_text("> Les révélations de ce laboratoire pourraient être la clé pour déchiffrer le mystère de son identité et des créatures qui hantent ce monde étrange.")
        display_text()
        wait_for_click()


def update_text(new_text):
    global current_text
    current_text = new_text

def display_text():
    screen.blit(background_image, (0, 0))
    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
    screen.fill(text_area_color, text_area_rect)

    x, y = text_area_rect.midleft
    for char in current_text:
        dialogue_text = font.render(char, True, (255, 255, 255))
        screen.blit(dialogue_text, (x, y))
        x += dialogue_text.get_width()
        pygame.display.flip()
        

    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False

def wait_for_click():
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False



# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Draw everything
    screen.blit(background_image, (0, 0))
    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
    screen.fill(text_area_color, text_area_rect)

    # Display the text
    update_text("> …")
    display_text()
    wait_for_click()
    pygame.mixer.music.play(-1)
    update_text("> Le joueur émerge du bâtiment, le souffle court, prêt à affronter l'inconnu qui s'étend devant lui.")
    display_text()
    wait_for_click()

    update_text("> Autour de lui, la ville semble endormie, ses rues désertes témoignant du mystère qui l'entoure.")
    display_text()
    wait_for_click()
    
    update_text("> Dans ca main se trouve une photo, inscrit une adresse inconnu.")
    display_text()
    wait_for_click()

    update_text("> Son subconscient murmure, un flux constant de suggestions qui dansent dans les recoins de son esprit, offrant des conseils sur les chemins à prendre.")
    display_text()
    wait_for_click()

    update_text("> Le narrateur observe silencieusement, attendant de voir quel choix le joueur fera, quelle voie il décidera d'explorer dans cette histoire en devenir.")
    display_text()
    wait_for_click()

    update_text("> Quel chemin choisira le joueur ?")
    display_text()
    wait_for_click()

    update_text("")
    display_text()
    # Set up the choice buttons
    button_font = pygame.font.Font(None, 24)
    button_width = 600
    button_height = 30
    button_margin = 10
    button_color = (255, 255, 255)
    button_text_color = (0, 0, 0)

    choices = [
    {"text": "1 - Se rendre à la supérette la plus proche pour se réapprovisionner.", "rect": pygame.Rect(20, 570, button_width, button_height)},
    {"text": "2 - Suivre directement l'adresse inscrite sur la photo, bravant l'inconnu.", "rect": pygame.Rect(20, 610, button_width, button_height)},
    {"text": "3 - Parcourir les rues à la recherche d'un endroit sûr où se réfugier.", "rect": pygame.Rect(20, 650, button_width, button_height)},
    ]

    def display_choices():
        for choice in choices:
            pygame.draw.rect(screen, button_color, choice["rect"])
            button_text = button_font.render(choice["text"], True, button_text_color)
            screen.blit(button_text, (choice["rect"].x + 10, choice["rect"].y + 5))
        pygame.display.flip()

    display_choices()

        # Wait for the player to click on a choice
    choice_selected = None
    while choice_selected is None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for choice in choices:
                    if choice["rect"].collidepoint(event.pos):
                        choice_selected = choice["text"]
                        break


    if choice_selected == "3 - Parcourir les rues à la recherche d'un endroit sûr où se réfugier.":
        # Load and scale the background image
        background_image = pygame.image.load("rue.png")
        background_image = pygame.transform.scale(background_image, (screen_width, screen_height))
        pygame.mixer.music.stop()
        music_file = "deathstreet.mp3"
        pygame.mixer.music.load(music_file)
        pygame.mixer.music.play(-1)

        # Set up the font
        font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

        # Set up the text area
        text_area_color = (0, 0, 0)
        text_area_height = 140
        text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

        # Draw everything
        screen.blit(background_image, (0, 0))
        pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
        screen.fill(text_area_color, text_area_rect)


        # Display the text

        c3()

        # Load and scale the background image
        background_image = pygame.image.load("Black.png")
        background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


        # Set up the font
        font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

        # Set up the text area
        text_area_color = (0, 0, 0)
        text_area_height = 140
        text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

        # Draw everything
        screen.blit(background_image, (0, 0))
        pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
        screen.fill(text_area_color, text_area_rect)

        update_text("> GameOver…")
        display_text()
        wait_for_click()
        pygame.quit()
        sys.exit()
    elif choice_selected == "1 - Se rendre à la supérette la plus proche pour se réapprovisionner.":
        # Load and scale the background image
        background_image = pygame.image.load("FacadeSupérette.png")
        background_image = pygame.transform.scale(background_image, (screen_width, screen_height))
        pygame.mixer.music.stop()
        music_file = "superette.mp3"
        pygame.mixer.music.load(music_file)
        pygame.mixer.music.play(-1)

        # Set up the font
        font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

        # Set up the text area
        text_area_color = (0, 0, 0)
        text_area_height = 140
        text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

        # Draw everything
        screen.blit(background_image, (0, 0))
        pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
        screen.fill(text_area_color, text_area_rect)

         
        # Display the text
        update_text("> Le joueur entre dans la supérette, scrutant les environs avec méfiance.")
        display_text()
        wait_for_click()
        # Load and scale the background image
        background_image = pygame.image.load("dansSupérette.png")
        background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


        # Set up the font
        font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

        # Set up the text area
        text_area_color = (0, 0, 0)
        text_area_height = 140
        text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

        # Draw everything
        screen.blit(background_image, (0, 0))
        pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
        screen.fill(text_area_color, text_area_rect)

        update_text("> Soudain, une force invisible le projette violemment au sol.")
        display_text()
        wait_for_click()

        update_text("> Joueur: se relevant péniblement Qu'est-ce qui s'est passé ?")
        display_text()
        wait_for_click()

        update_text("> Homme mystérieux: Désolé pour ça. Je pensais que tu étais l'une de ces créatures, elles sont partout, tu sais.")
        display_text()
        wait_for_click()

        update_text("> Joueur: Créatures ? De quoi tu parles ?")
        display_text()
        wait_for_click()

        update_text("> Homme mystérieux: Les habitants sans visage. En général, ils sont inoffensifs, mais certains... méfie-toi d'eux.")
        display_text()
        wait_for_click()

        update_text("> Joueur se frotte la tête, encore sous le choc de la chute.")
        display_text()
        wait_for_click()

        update_text("> Joueur: Je... je ne me souviens de rien. Pas même de mon nom.")
        display_text()
        wait_for_click()

        update_text("> Homme mystérieux: Moi non plus. C'est comme si tout avait été effacé. Mais nous devons nous entraider pour comprendre ce qui se passe ici.")
        display_text()
        wait_for_click()

        update_text("> Le joueur acquiesce lentement, acceptant l'idée d'unir leurs forces pour démêler ce mystère.")
        display_text()
        wait_for_click()

        update_text("> Toi : D'accord. Que sais-tu sur ces créatures ?")
        display_text()
        wait_for_click()

        update_text("> Homme mystérieux: Pas grand-chose. Elles sont étranges, c'est sûr. Mais il y a quelque chose de plus étrange encore...")
        display_text()
        wait_for_click()

        update_text("> L'homme sort une montre de sa poche, montrant l'inscription \"Taro\" gravée dessus.")
        display_text()
        wait_for_click()

        update_text("> Homme mystérieux: C'est tout ce que j'ai trouvé sur moi. Et cette feuille avec une adresse... la même que celle que tu tiens.")
        display_text()
        wait_for_click()

        update_text("> Joueur examine la montre et la feuille avec curiosité, se demandant quel lien elles peuvent avoir avec leur situation.")
        display_text()
        wait_for_click()

        update_text("> Le subconscient du joueur murmure, des fragments de mémoire tentant de se frayer un chemin à travers l'obscurité de l'amnésie.")
        display_text()
        wait_for_click()

        update_text("> Comment le joueur réagira-t-il à ces révélations ?")
        display_text()
        wait_for_click()

        update_text("")
        display_text()
        # Set up the choice buttons
        button_font = pygame.font.Font(None, 24)
        button_width = 930
        button_height = 30
        button_margin = 10
        button_color = (255, 255, 255)
        button_text_color = (0, 0, 0)
        choices = [
        {"text": "1 - 'Tu m'as déjà assez inquiété avec ces histoires de créatures. Je vais me débrouiller seul.'", "rect": pygame.Rect(20, 570, button_width, button_height)},
        {"text": "2 - 'C'est bizarre, mais je suppose que j'ai besoin de toute l'aide que je peux obtenir. On devrait enquêter ensemble.'", "rect": pygame.Rect(20, 610, button_width, button_height)},
        {"text": "3 - 'Je vais chercher des indices supplémentaires pour essayer de comprendre ce qui se passe ici.'", "rect": pygame.Rect(20, 650, button_width, button_height)},
        ]  

        display_choices()

         # Wait for the player to click on a choice
        choice_selected = None
        while choice_selected is None:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    for choice in choices:
                     if choice["rect"].collidepoint(event.pos):
                        choice_selected = choice["text"]
                        break
        if choice_selected == "3 - 'Je vais chercher des indices supplémentaires pour essayer de comprendre ce qui se passe ici.'":
                    # Load and scale the background image
            background_image = pygame.image.load("rue.png")
            background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


            # Set up the font
            font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

            # Set up the text area
            text_area_color = (0, 0, 0)
            text_area_height = 140
            text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

            # Draw everything
            screen.blit(background_image, (0, 0))
            pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
            screen.fill(text_area_color, text_area_rect)


            # Display the text

            c3()

            # Load and scale the background image
            background_image = pygame.image.load("Black.png")
            background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


            # Set up the font
            font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

            # Set up the text area
            text_area_color = (0, 0, 0)
            text_area_height = 140
            text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

            # Draw everything
            screen.blit(background_image, (0, 0))
            pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
            screen.fill(text_area_color, text_area_rect)

            update_text("> GameOver…")
            display_text()
            wait_for_click()
            pygame.quit()
            sys.exit()             
        elif choice_selected == "2 - 'C'est bizarre, mais je suppose que j'ai besoin de toute l'aide que je peux obtenir. On devrait enquêter ensemble.'":    
            #A1
            update_text("> Le joueur, accompagné de Taro, décide de se diriger vers l'adresse inscrite sur la photo.")
            display_text()
            wait_for_click()
            pygame.mixer.music.stop()
            music_file = "usine.mp3"
            pygame.mixer.music.load(music_file)
            pygame.mixer.music.play(-1)

                # Load image
            background_image = pygame.image.load("Usine.png")
            background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


            # Set up the font
            font = pygame.font.Font(None, 24)

            # Set up the text area
            text_area_color = (0, 0, 0)
            text_area_height = 140
            text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

            # Draw everything
            screen.blit(background_image, (0, 0))
            pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
            screen.fill(text_area_color, text_area_rect)

            update_text("> Ils arrivent devant une usine abandonnée et, en y entrant, trouvent des créatures sans visage travaillant à la création de quelque chose de non identifié.")
            display_text()
            wait_for_click()

            update_text("> Ils continuent d'avancer et tombent nez à nez avec des créatures menaçantes qui commencent à les attaquer.")
            display_text()
            wait_for_click()

                # Load image
            background_image = pygame.image.load("Labo.png")
            background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


            # Set up the font
            font = pygame.font.Font(None, 24)

            # Set up the text area
            text_area_color = (0, 0, 0)
            text_area_height = 140
            text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

            # Draw everything
            screen.blit(background_image, (0, 0))
            pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
            screen.fill(text_area_color, text_area_rect)


            update_text("> Que feront-ils ?")
            display_text()
            wait_for_click()

            update_text("")
            display_text()
            # Set up the choice buttons
            button_font = pygame.font.Font(None, 24)
            button_width = 600
            button_height = 30
            button_margin = 10
            button_color = (255, 255, 255)
            button_text_color = (0, 0, 0)
            choices = [
            {"text": "1 - Fuir par une porte malgré le signe 'DANGER' sur elle.", "rect": pygame.Rect(20, 570, button_width, button_height)},
            {"text": "2 - Combattre les monstres.", "rect": pygame.Rect(20, 610, button_width, button_height)},
            ]  

            display_choices()

            # Wait for the player to click on a choice
            choice_selected = None
            while choice_selected is None:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        for choice in choices:
                            if choice["rect"].collidepoint(event.pos):
                                choice_selected = choice["text"]
                                break
            if choice_selected == "1 - Fuir par une porte malgré le signe 'DANGER' sur elle.":
                #SalleDANGER+Taro
                    # Load image

                background_image = pygame.image.load("urnes.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))
                pygame.mixer.music.stop()


                # Set up the font
                font = pygame.font.Font(None, 24)
                music_file = "deathstreet.mp3"
                pygame.mixer.music.load(music_file)
                pygame.mixer.music.play(-1)

                # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)

                SalleDangerTaro()

                # Load image
                background_image = pygame.image.load("Black.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)

                update_text("> To be continued...")
                pygame.mixer.music.stop()
                display_text()
                pygame.quit()
                sys.exit()
            elif choice_selected == "2 - Combattre les monstres.":
                update_text("> Le joueur et Taro se lancent dans la bataille. Taro, armé de son fusil à pompe, tire avec précision sur l'ombre d'une des créatures, la faisant exploser.")
                display_text()
                wait_for_click()

                pygame.mixer.music.stop()
                music_file = "usine.mp3"
                pygame.mixer.music.load(music_file)
                pygame.mixer.music.play(-1)

                update_text("> Taro : essoufflé Leur ombre est leur point faible. On doit viser juste.")
                display_text()
                wait_for_click()

                update_text("> Ils poursuivent leur chemin à travers l'usine, avançant prudemment dans un couloir sombre.")
                display_text()
                wait_for_click()

                update_text("> Soudain, ils atteignent un cul-de-sac. Au fond du ravin, ils distinguent une vision cauchemardesque :")
                display_text()
                wait_for_click()

                # Load image
                background_image = pygame.image.load("piles.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)

                update_text("> ...des enfants sans visage, empalés les uns sur les autres.")
                display_text()
                wait_for_click()

                update_text("> Joueur : horrifié Mon Dieu, qu'est-ce que c'est que ça ?")
                display_text()
                wait_for_click()

                update_text("> Taro : serrant les dents On ne peut rien faire pour eux maintenant. Revenons sur nos pas. Il doit y avoir une autre issue quelque part.")
                display_text()
                wait_for_click()

                update_text("> Ils rebroussent chemin, décidés à explorer d'autres pistes pour trouver des réponses.")
                display_text()
                wait_for_click()

                    # Load image
                background_image = pygame.image.load("Black.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)

                update_text("> To be continued...")
                display_text()
                pygame.mixer.music.stop()

                pygame.quit()
                sys.exit()
        #End of A1
        elif choice_selected == "1 - 'Tu m'as déjà assez inquiété avec ces histoires de créatures. Je vais me débrouiller seul.'":
            #Rediriger vers la mm chose que Choix 2
                # Load image
            background_image = pygame.image.load("Facade.png")
            background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
            font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
            text_area_color = (0, 0, 0)
            text_area_height = 140
            text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
            screen.blit(background_image, (0, 0))
            pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
            screen.fill(text_area_color, text_area_rect)
            pygame.mixer.music.load("usine.mp3")
            pygame.mixer.music.play(-1)
            update_text("> Le joueur, décidant de suivre l'adresse inscrite sur la photo, se retrouve face à une imposante usine une fois sur place.")
            display_text()
            wait_for_click()

                # Load image
            background_image = pygame.image.load("usine.png")
            background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
            font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
            text_area_color = (0, 0, 0)
            text_area_height = 140
            text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
            screen.blit(background_image, (0, 0))
            pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
            screen.fill(text_area_color, text_area_rect)

            update_text("> Sans se laisser intimider par son apparence lugubre, il franchit ses portes, pénétrant dans un monde mystérieux où les créatures sans visage s'affairent comme des automates, indifférentes à sa présence.")
            display_text()
            wait_for_click()

            update_text("> Joueur : observant avec méfiance les créatures qui vaquent à leurs occupations C'est quoi cet endroit ?")
            display_text()
            wait_for_click()

            update_text("> Alors qu'il s'engage plus profondément dans l'usine, le joueur se retrouve soudainement encerclé par ces êtres énigmatiques, leurs gestes dépourvus d'expression le laissant perplexe.")
            display_text()
            wait_for_click()

            update_text("> Dans sa confusion, il prend ces créatures pour des gardes et cherche une issue.")
            display_text()
            wait_for_click()

            update_text("> Joueur : regardant autour de lui, cherchant une échappatoire Bon sang, comment je vais m'en sortir d'ici ?")
            display_text()
            wait_for_click()

            update_text("> Trois choix s'offrent à lui, chacun portant son lot de risques et de possibilités.")
            display_text()
            wait_for_click()

            update_text("")
            display_text()
            # Set up the choice buttons
            button_font = pygame.font.Font(None, 24)
            button_width = 930
            button_height = 30
            button_margin = 10
            button_color = (255, 255, 255)
            button_text_color = (0, 0, 0)
            choices = [
            {"text": "1 - Il s'enfuit vers une salle proche malgré le panneau annonçant le danger", "rect": pygame.Rect(20, 570, button_width, button_height)},
            {"text": "2 - Il saute dans un trou vers l'aération de l'usine", "rect": pygame.Rect(20, 610, button_width, button_height)},
            {"text": "3 - Il tente de se battre contre eux", "rect": pygame.Rect(20, 650, button_width, button_height)},
            ]  

            display_choices()

            # Wait for the player to click on a choice
            choice_selected = None
            while choice_selected is None:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        for choice in choices:
                            if choice["rect"].collidepoint(event.pos):
                                choice_selected = choice["text"]
                                break
            if choice_selected == "3 - Il tente de se battre contre eux":
                update_text("> Malheureuseument, ils sont biens trops nombreux...")
                display_text()
                wait_for_click()
                    # Load image
                background_image = pygame.image.load("Black.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                    # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                    # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                    # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)

                update_text("> Game Over...")
                display_text()
                pygame.mixer.music.stop()
                pygame.quit()
                sys.exit()
            elif choice_selected == "1 - Il s'enfuit vers une salle proche malgré le panneau annonçant le DANGER":
                #SalleDANGER
                    # Load image
                background_image = pygame.image.load("urnes.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))
                pygame.mixer.music.stop()
                pygame.mixer.music.load("deathstreet.mp3")
                pygame.mixer.music.play(-1)
                    # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                    # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                    # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)

                update_text("> Joueur : regardant autour de lui Où suis-je ?")
                display_text()
                wait_for_click()

                update_text("> En explorant la pièce, il remarque plusieurs urnes contenant des liquides noirs. Son attention est attirée par un bureau encombré de papiers.")
                display_text()
                wait_for_click()

                update_text("> En fouillant, il trouve un bout de papier déchiré provenant probablement d'un cahier.")
                display_text()
                wait_for_click()

                update_text("> Joueur : lisant le bout de papier 'Mon mari et moi avançons très vite sur le projet, les homonculus sont quasi autonomes, l'assignation de tâches sera bientôt possible.'")
                display_text()
                wait_for_click()

                update_text("> Intrigué, le joueur continue son exploration, découvrant d'autres pages du journal éparpillées sur le bureau.")
                display_text()
                wait_for_click()

                update_text("> Joueur : lisant la deuxième page 'Les homonculus sont enfin fonctionnels, ils commenceront à opérer dès demain dans l'usine. Mon mari et moi sommes très satisfaits du résultat.'")
                display_text()
                wait_for_click()

                update_text("> Joueur : feuilletant la troisième page 'Les homonculus ont été déployés dans toute la ville. C'est dommage qu'il ne soit pas là pour voir le fruit de nos efforts.'")
                display_text()
                wait_for_click()

                update_text("> Joueur : s'arrêtant sur la dernière page lisible 'J'ai commencé des travaux sur l'implémentation de sentiments aux homonculus, j'espère que ça se concrétisera bientôt.'")
                display_text()
                wait_for_click()

                update_text("> Le reste du journal est déchiré, rendant la lecture impossible. Cependant, une moitié de photo d'une femme reste intacte à la fin du journal.")
                display_text()
                wait_for_click()

                update_text("> Au verso, le nom 'Samantha' est écrit.")
                display_text()
                wait_for_click()

                update_text("> Joueur : regardant la photo Samantha... Qui est-elle ?")
                display_text()
                wait_for_click()

                update_text("> En avançant plus loin dans le laboratoire, le joueur découvre une énorme machine.")
                display_text()
                wait_for_click()

                update_text("> Il trouva un nom inscrit dessus, malgré son amnésie il le connaissait très bien, car ce nom n’était nul autre que le sien.")
                display_text()
                wait_for_click()

                update_text("> Joueur : ébahi Mon nom ? Qu'est-ce que tout cela signifie ?")
                display_text()
                wait_for_click()

                update_text("> Le subconscient du joueur s'agite, des fragments de souvenirs tentant de remonter à la surface.")
                display_text()
                wait_for_click()

                update_text("> La vérité semble proche, mais encore hors de portée.")
                display_text()
                wait_for_click()

                update_text("> Les révélations de ce laboratoire pourraient être la clé pour déchiffrer le mystère de son identité et des créatures qui hantent ce monde étrange.")
                display_text()
                wait_for_click()
                    # Load image
                background_image = pygame.image.load("Black.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)

                update_text("> To be continued...")
                display_text()
                pygame.mixer.music.stop()

                pygame.quit()
                sys.exit()
            elif choice_selected == "2 - Il saute dans un trou vers l'aération de l'usine":
                pygame.mixer.music.stop()
                pygame.mixer.music.load("usine.mp3")
                pygame.mixer.music.play(-1)

                background_image = pygame.image.load("Black.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)


                update_text("> Le joueur, optant pour une retraite rapide, saute dans un trou menant aux conduits d'aération de l'usine.")
                display_text()
                wait_for_click()

                update_text("> Rampant à travers les conduits étroits, il avance avec précaution, espérant trouver une sortie ou un endroit sûr.")
                display_text()
                wait_for_click()

                update_text("> Après quelques minutes, il émerge dans une salle inconnue et se retrouve soudainement face à un homme armé d'un fusil à pompe.")
                display_text()
                wait_for_click()

                update_text("> Joueur: surpris Oh non... qui êtes-vous ?")
                display_text()
                wait_for_click()

                update_text("> L'homme, visiblement tendu mais humain, le regarde avec méfiance, le doigt sur la détente.")
                display_text()
                wait_for_click()

                update_text("> Plusieurs choix s'offrent au joueur :")
                display_text()
                wait_for_click()

                update_text("")
                display_text()
                # Set up the choice buttons
                button_font = pygame.font.Font(None, 24)
                button_width = 600
                button_height = 30
                button_margin = 10
                button_color = (255, 255, 255)
                button_text_color = (0, 0, 0)
                choices = [
                {"text": "1 - Lui parler", "rect": pygame.Rect(20, 570, button_width, button_height)},
                {"text": "2 - Essayer de fuir", "rect": pygame.Rect(20, 610, button_width, button_height)},
                ]  

                display_choices()

                # Wait for the player to click on a choice
                choice_selected = None
                while choice_selected is None:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            for choice in choices:
                                if choice["rect"].collidepoint(event.pos):
                                    choice_selected = choice["text"]
                                    break
                if choice_selected == "2 - Essayer de fuir":
                    update_text("> Joueur: regardant autour de lui, cherchant une issue Je dois sortir d'ici")
                    display_text()
                    pygame.mixer.music.stop()
                    pygame.mixer.music.load("deathstreet.mp3")
                    pygame.mixer.music.play(-1)
                    wait_for_click()

                    update_text("> L'homme lui tire dessus sans sommation.")
                    display_text()
                    wait_for_click()
                                        # Load image
                    background_image = pygame.image.load("Black.png")
                    background_image = pygame.transform.scale(background_image, (screen_width, screen_height))

                    font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                        # Set up the text area
                    text_area_color = (0, 0, 0)
                    text_area_height = 140
                    text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                        # Draw everything
                    screen.blit(background_image, (0, 0))
                    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                    screen.fill(text_area_color, text_area_rect)

                    update_text("> Game Over...")
                    display_text()
                    pygame.quit()
                    pygame.mixer.music.stop()
                    sys.exit()
                elif choice_selected == "1 - Lui parler":
                    pygame.mixer.music.stop()
                    pygame.mixer.music.load("start.mp3")
                    pygame.mixer.music.play(-1)
                    update_text("> Joueur : levant les mains en signe de paix")
                    display_text()
                    wait_for_click()

                    update_text("> Attendez, attendez ! Je ne veux pas de mal.")
                    display_text()
                    wait_for_click()

                    update_text("> Je suis comme vous, je cherche des réponses.")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : toujours sur ses gardes, gardant son fusil pointé")
                    display_text()
                    wait_for_click()

                    update_text("> Comment je peux savoir que vous n'êtes pas l'un de ces monstres ?")
                    display_text()
                    wait_for_click()

                    update_text("> Joueur : calmement")
                    display_text()
                    wait_for_click()

                    update_text("> Regardez-moi.")
                    display_text()
                    wait_for_click()

                    update_text("> Je suis humain, tout comme vous.")
                    display_text()
                    wait_for_click()

                    update_text("> Je ne suis pas ici pour vous faire du mal.")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : relâchant légèrement sa prise sur le fusil")
                    display_text()
                    wait_for_click()

                    update_text("> D'accord. Mais restez où vous êtes.")
                    display_text()
                    wait_for_click()

                    update_text("> Joueur : hochant la tête")
                    display_text()
                    wait_for_click()

                    update_text("> D'accord.")
                    display_text()
                    wait_for_click()

                    update_text("> Pouvez-vous me dire ce que vous savez ?")
                    display_text()
                    wait_for_click()

                    update_text("> Pourquoi êtes-vous ici ?")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : soupirant")
                    display_text()
                    wait_for_click()

                    update_text("> Ça fait plusieurs jours que je vagabonde sans souvenirs.")
                    display_text()
                    wait_for_click()

                    update_text("> Je ne sais pas comment je suis arrivé ici.")
                    display_text()
                    wait_for_click()

                    update_text("> Je n'ai aucun souvenir de ma vie avant ça.")
                    display_text()
                    wait_for_click()

                    update_text("> Joueur : fronçant les sourcils")
                    display_text()
                    wait_for_click()

                    update_text("> Moi aussi, je suis dans la même situation.")
                    display_text()
                    wait_for_click()

                    update_text("> J'ai trouvé une photo avec une adresse, et je suis venu ici pour chercher des réponses.")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : hochant la tête")
                    display_text()
                    wait_for_click()

                    update_text("> Pareil pour moi.")
                    display_text()
                    wait_for_click()

                    update_text("> J'ai trouvé un papier avec cette adresse")
                    display_text()
                    wait_for_click()

                    update_text("> et il disait que je trouverais des réponses à mes questions ici.")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : Alors, j'ai suivi les indications")
                    display_text()
                    wait_for_click()

                    update_text("> et me voilà.")
                    display_text()
                    wait_for_click()

                    update_text("> Joueur : regardant autour de lui")
                    display_text()
                    wait_for_click()

                    update_text("> Et avez-vous trouvé quelque chose ?")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : soupirant")
                    display_text()
                    wait_for_click()

                    update_text("> Pas encore. Mais je suis certain que nous sommes sur la bonne piste.")
                    display_text()
                    wait_for_click()

                    update_text("> Je m'appelle Taro, au fait. C'est ce qui est écrit sur ma montre.")
                    display_text()
                    wait_for_click()

                    update_text("> Joueur : souriant légèrement")
                    display_text()
                    wait_for_click()

                    update_text("> Enchanté, Taro.")
                    display_text()
                    wait_for_click()

                    update_text("> Le joueur réalise qu'il ne se souvient toujours pas de son propre nom")
                    display_text()
                    wait_for_click()

                    update_text("> une frustration palpable sur son visage.")
                    display_text()
                    wait_for_click()

                    update_text("> Taro : remarquant l'hésitation du joueur")
                    display_text()
                    wait_for_click()

                    update_text("> ne t'inquiète pas.")
                    display_text()
                    wait_for_click()

                    update_text("> Nous allons trouver des réponses, ensemble.")
                    display_text()
                    wait_for_click()

                    update_text("> Le subconscient du joueur s'agite des fragments de mémoire tentant de se frayer un chemin à travers l'obscurité de l'amnésie.")
                    display_text()
                    wait_for_click()


                    update_text("> Le joueur et Taro décidant de continuer à explorer ensemble avancent prudemment à travers l'usine.")
                    display_text()
                    wait_for_click()


                    update_text("> Leurs pas résonnent dans le silence oppressant chaque coin obscur dissimulant des mystères potentiellement dangereux.")
                    display_text()
                    wait_for_click()

                    update_text("> chaque coin obscur dissimulant des mystères potentiellement dangereux.")
                    display_text()
                    wait_for_click()

                    background_image = pygame.image.load("urnes.png")
                    background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                    # Set up the font
                    font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                    # Set up the text area
                    text_area_color = (0, 0, 0)
                    text_area_height = 140
                    text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                    # Draw everything
                    screen.blit(background_image, (0, 0))
                    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                    screen.fill(text_area_color, text_area_rect)

                    update_text("> Finalement, ils arrivent dans un laboratoire rempli d'urnes contenant un liquide noir et mystérieux.")
                    display_text()
                    pygame.mixer.music.stop()
                    pygame.mixer.music.load("usine.mp3")
                    pygame.mixer.music.play(-1)
                    wait_for_click()

                    SalleDangerTaro()
                    # Load image
                    background_image = pygame.image.load("Black.png")
                    background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                    # Set up the font
                    font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                    # Set up the text area
                    text_area_color = (0, 0, 0)
                    text_area_height = 140
                    text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                    # Draw everything
                    screen.blit(background_image, (0, 0))
                    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                    screen.fill(text_area_color, text_area_rect)

                    update_text("> To be continued...")
                    display_text()
                    pygame.mixer.music.stop()
                    pygame.quit()
                    sys.exit()

                    




    elif choice_selected == "2 - Suivre directement l'adresse inscrite sur la photo, bravant l'inconnu.":
        
        #Same stuff as above cmd c cmd v because idk how to use pointers in py
    
                # Load image
            background_image = pygame.image.load("Facade.png")
            background_image = pygame.transform.scale(background_image, (screen_width, screen_height))



            font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
            text_area_color = (0, 0, 0)
            text_area_height = 140
            text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
            screen.blit(background_image, (0, 0))
            pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
            screen.fill(text_area_color, text_area_rect)
        
            update_text("> Le joueur, décidant de suivre l'adresse inscrite sur la photo, se retrouve face à une imposante usine une fois sur place.")
            display_text()
            pygame.mixer.music.stop()
            pygame.mixer.music.load("usine.mp3")
            pygame.mixer.music.play(-1)

            wait_for_click()

                # Load image
            background_image = pygame.image.load("usine.png")
            background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
            font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
            text_area_color = (0, 0, 0)
            text_area_height = 140
            text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
            screen.blit(background_image, (0, 0))
            pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
            screen.fill(text_area_color, text_area_rect)

            update_text("> Sans se laisser intimider par son apparence lugubre, il franchit ses portes, pénétrant dans un monde mystérieux où les créatures sans visage s'affairent comme des automates, indifférentes à sa présence.")
            display_text()
            wait_for_click()

            update_text("> Joueur : observant avec méfiance les créatures qui vaquent à leurs occupations C'est quoi cet endroit ?")
            display_text()
            wait_for_click()

            update_text("> Alors qu'il s'engage plus profondément dans l'usine, le joueur se retrouve soudainement encerclé par ces êtres énigmatiques, leurs gestes dépourvus d'expression le laissant perplexe.")
            display_text()
            wait_for_click()

            update_text("> Dans sa confusion, il prend ces créatures pour des gardes et cherche une issue.")
            display_text()
            wait_for_click()

            update_text("> Joueur : regardant autour de lui, cherchant une échappatoire Bon sang, comment je vais m'en sortir d'ici ?")
            display_text()
            wait_for_click()

            update_text("> Trois choix s'offrent à lui, chacun portant son lot de risques et de possibilités.")
            display_text()
            wait_for_click()

            update_text("")
            display_text()
            # Set up the choice buttons
            font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)
            button_width = 930
            button_height = 30
            button_margin = 10
            button_color = (255, 255, 255)
            button_text_color = (0, 0, 0)
            choices = [
            {"text": "1 - Il s'enfuit vers une salle proche malgré le panneau annonçant le DANGER", "rect": pygame.Rect(20, 570, button_width, button_height)},
            {"text": "2 - Il saute dans un trou vers l'aération de l'usine", "rect": pygame.Rect(20, 610, button_width, button_height)},
            {"text": "3 - Il tente de se battre contre eux", "rect": pygame.Rect(20, 650, button_width, button_height)},
            ]  

            display_choices()

            # Wait for the player to click on a choice
            choice_selected = None
            while choice_selected is None:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        for choice in choices:
                            if choice["rect"].collidepoint(event.pos):
                                choice_selected = choice["text"]
                                break
            if choice_selected == "3 - Il tente de se battre contre eux":
                update_text("> Malheureuseument, ils sont biens trops nombreux...")
                display_text()
                pygame.mixer.music.stop()
                pygame.mixer.music.load("deathstreet.mp3")
                pygame.mixer.music.play(-1)
                wait_for_click()
                    # Load image
                background_image = pygame.image.load("Black.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                    # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                    # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                    # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)

                update_text("> Game Over...")
                display_text()
                pygame.mixer.music.stop()
                pygame.quit()
                sys.exit()
            elif choice_selected == "1 - Il s'enfuit vers une salle proche malgré le panneau annonçant le DANGER":
                #SalleDANGER
                    # Load image
                background_image = pygame.image.load("urnes.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))

                    # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                    # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                    # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)
                update_text("> Joueur : regardant autour de lui Où suis-je ?")
                display_text()
                pygame.mixer.music.load("deathstreet.mp3")
                pygame.mixer.music.play(-1)
                wait_for_click()

                update_text("> En explorant la pièce, il remarque plusieurs urnes contenant des liquides noirs. Son attention est attirée par un bureau encombré de papiers.")
                display_text()
                pygame.mixer.music.stop()
                wait_for_click()

                update_text("> En fouillant, il trouve un bout de papier déchiré provenant probablement d'un cahier.")
                display_text()
                wait_for_click()

                update_text("> Joueur : lisant le bout de papier 'Mon mari et moi avançons très vite sur le projet, les homonculus sont quasi autonomes, l'assignation de tâches sera bientôt possible.'")
                display_text()
                wait_for_click()

                update_text("> Intrigué, le joueur continue son exploration, découvrant d'autres pages du journal éparpillées sur le bureau.")
                display_text()
                wait_for_click()

                update_text("> Joueur : lisant la deuxième page 'Les homonculus sont enfin fonctionnels, ils commenceront à opérer dès demain dans l'usine. Mon mari et moi sommes très satisfaits du résultat.'")
                display_text()
                wait_for_click()

                update_text("> Joueur : feuilletant la troisième page 'Les homonculus ont été déployés dans toute la ville. C'est dommage qu'il ne soit pas là pour voir le fruit de nos efforts.'")
                display_text()
                wait_for_click()

                update_text("> Joueur : s'arrêtant sur la dernière page lisible 'J'ai commencé des travaux sur l'implémentation de sentiments aux homonculus, j'espère que ça se concrétisera bientôt.'")
                display_text()
                wait_for_click()

                update_text("> Le reste du journal est déchiré, rendant la lecture impossible. Cependant, une moitié de photo d'une femme reste intacte à la fin du journal.")
                display_text()
                wait_for_click()

                update_text("> Au verso, le nom 'Samantha' est écrit.")
                display_text()
                wait_for_click()

                update_text("> Joueur : regardant la photo Samantha... Qui est-elle ?")
                display_text()
                wait_for_click()

                update_text("> En avançant plus loin dans le laboratoire, le joueur découvre une énorme machine.")
                display_text()
                wait_for_click()

                update_text("> Il trouva un nom inscrit dessus, malgré son amnésie il le connaissait très bien, car ce nom n’était nul autre que le sien.")
                display_text()
                wait_for_click()

                update_text("> Joueur : ébahi Mon nom ? Qu'est-ce que tout cela signifie ?")
                display_text()
                wait_for_click()

                update_text("> Le subconscient du joueur s'agite, des fragments de souvenirs tentant de remonter à la surface.")
                display_text()
                wait_for_click()

                update_text("> La vérité semble proche, mais encore hors de portée.")
                display_text()
                wait_for_click()

                update_text("> Les révélations de ce laboratoire pourraient être la clé pour déchiffrer le mystère de son identité et des créatures qui hantent ce monde étrange.")
                display_text()
                wait_for_click()
                    # Load image
                background_image = pygame.image.load("Black.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)

                update_text("> To be continued...")
                display_text()
                pygame.mixer.music.stop()
                pygame.quit()
                sys.exit()
            elif choice_selected == "2 - Il saute dans un trou vers l'aération de l'usine":

                background_image = pygame.image.load("Black.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)


                update_text("> Le joueur, optant pour une retraite rapide, saute dans un trou menant aux conduits d'aération de l'usine.")
                display_text()
                pygame.mixer.music.stop()
                pygame.mixer.music.load("deathstreet.mp3")
                pygame.mixer.music.play(-1)
                wait_for_click()

                update_text("> Rampant à travers les conduits étroits, il avance avec précaution, espérant trouver une sortie ou un endroit sûr.")
                display_text()
                wait_for_click()

                background_image = pygame.image.load("SalleInconnu.png")
                background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                # Set up the font
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                # Set up the text area
                text_area_color = (0, 0, 0)
                text_area_height = 140
                text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                # Draw everything
                screen.blit(background_image, (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                screen.fill(text_area_color, text_area_rect)

                update_text("> Après quelques minutes, il émerge dans une salle inconnue et se retrouve soudainement face à un homme armé d'un fusil à pompe.")
                display_text()
                wait_for_click()

                update_text("> Joueur: surpris Oh non... qui êtes-vous ?")
                display_text()
                wait_for_click()

                update_text("> L'homme, visiblement tendu mais humain, le regarde avec méfiance, le doigt sur la détente.")
                display_text()
                wait_for_click()

                update_text("> Plusieurs choix s'offrent au joueur :")
                display_text()
                wait_for_click()

                update_text("")
                display_text()
                # Set up the choice buttons
                font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)
                button_width = 600
                button_height = 30
                button_margin = 10
                button_color = (255, 255, 255)
                button_text_color = (0, 0, 0)
                choices = [
                {"text": "1 - Lui parler", "rect": pygame.Rect(20, 570, button_width, button_height)},
                {"text": "2 - Essayer de fuir", "rect": pygame.Rect(20, 610, button_width, button_height)},
                ]  

                display_choices()

                # Wait for the player to click on a choice
                choice_selected = None
                while choice_selected is None:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            for choice in choices:
                                if choice["rect"].collidepoint(event.pos):
                                    choice_selected = choice["text"]
                                    break
                if choice_selected == "2 - Essayer de fuir":
                    update_text("> Joueur: regardant autour de lui, cherchant une issue Je dois sortir d'ici")
                    display_text()
                    pygame.mixer.music.stop()
                    pygame.mixer.music.load("deathstreet.mp3")
                    pygame.mixer.music.play(-1)
                    wait_for_click()

                    update_text("> L'homme lui tire dessus sans sommation.")
                    display_text()
                    wait_for_click()
                                        # Load image
                    background_image = pygame.image.load("Black.png")
                    background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                        # Set up the font
                    font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                        # Set up the text area
                    text_area_color = (0, 0, 0)
                    text_area_height = 140
                    text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                        # Draw everything
                    screen.blit(background_image, (0, 0))
                    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                    screen.fill(text_area_color, text_area_rect)

                    update_text("> Game Over...")
                    pygame.mixer.music.stop()
                    display_text()
                    pygame.quit()
                    sys.exit()
                elif choice_selected == "1 - Lui parler":
                    update_text("> Joueur : levant les mains en signe de paix")
                    pygame.mixer.music.stop()
                    pygame.mixer.music.load("start.mp3")
                    pygame.mixer.music.play(-1)
                    display_text()
                    wait_for_click()

                    update_text("> Attendez, attendez ! Je ne veux pas de mal.")
                    display_text()
                    wait_for_click()

                    update_text("> Je suis comme vous, je cherche des réponses.")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : toujours sur ses gardes, gardant son fusil pointé")
                    display_text()
                    wait_for_click()

                    update_text("> Comment je peux savoir que vous n'êtes pas l'un de ces monstres ?")
                    display_text()
                    wait_for_click()

                    update_text("> Joueur : calmement")
                    display_text()
                    wait_for_click()

                    update_text("> Regardez-moi.")
                    display_text()
                    wait_for_click()

                    update_text("> Je suis humain, tout comme vous.")
                    display_text()
                    wait_for_click()

                    update_text("> Je ne suis pas ici pour vous faire du mal.")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : relâchant légèrement sa prise sur le fusil")
                    display_text()
                    wait_for_click()

                    update_text("> D'accord. Mais restez où vous êtes.")
                    display_text()
                    wait_for_click()

                    update_text("> Joueur : hochant la tête")
                    display_text()
                    wait_for_click()

                    update_text("> D'accord.")
                    display_text()
                    wait_for_click()

                    update_text("> Pouvez-vous me dire ce que vous savez ?")
                    display_text()
                    wait_for_click()

                    update_text("> Pourquoi êtes-vous ici ?")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : soupirant")
                    display_text()
                    wait_for_click()

                    update_text("> Ça fait plusieurs jours que je vagabonde sans souvenirs.")
                    display_text()
                    wait_for_click()

                    update_text("> Je ne sais pas comment je suis arrivé ici.")
                    display_text()
                    wait_for_click()

                    update_text("> Je n'ai aucun souvenir de ma vie avant ça.")
                    display_text()
                    wait_for_click()

                    update_text("> Joueur : fronçant les sourcils")
                    display_text()
                    wait_for_click()

                    update_text("> Moi aussi, je suis dans la même situation.")
                    display_text()
                    wait_for_click()

                    update_text("> J'ai trouvé une photo avec une adresse, et je suis venu ici pour chercher des réponses.")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : hochant la tête")
                    display_text()
                    wait_for_click()

                    update_text("> Pareil pour moi.")
                    display_text()
                    wait_for_click()

                    update_text("> J'ai trouvé un papier avec cette adresse")
                    display_text()
                    wait_for_click()

                    update_text("> et il disait que je trouverais des réponses à mes questions ici.")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : Alors, j'ai suivi les indications")
                    display_text()
                    wait_for_click()

                    update_text("> et me voilà.")
                    display_text()
                    wait_for_click()

                    update_text("> Joueur : regardant autour de lui")
                    display_text()
                    wait_for_click()

                    update_text("> Et avez-vous trouvé quelque chose ?")
                    display_text()
                    wait_for_click()

                    update_text("> Homme : soupirant")
                    display_text()
                    wait_for_click()

                    update_text("> Pas encore. Mais je suis certain que nous sommes sur la bonne piste.")
                    display_text()
                    wait_for_click()

                    update_text("> Je m'appelle Taro, au fait. C'est ce qui est écrit sur ma montre.")
                    display_text()
                    wait_for_click()

                    update_text("> Joueur : souriant légèrement")
                    display_text()
                    wait_for_click()

                    update_text("> Enchanté, Taro.")
                    display_text()
                    wait_for_click()

                    update_text("> Le joueur réalise qu'il ne se souvient toujours pas de son propre nom")
                    display_text()
                    wait_for_click()

                    update_text("> une frustration palpable sur son visage.")
                    display_text()
                    wait_for_click()

                    update_text("> Taro : remarquant l'hésitation du joueur")
                    display_text()
                    wait_for_click()

                    update_text("> ne t'inquiète pas.")
                    display_text()
                    wait_for_click()

                    update_text("> Nous allons trouver des réponses, ensemble.")
                    display_text()
                    wait_for_click()

                    update_text("> Le subconscient du joueur s'agite des fragments de mémoire tentant de se frayer un chemin à travers l'obscurité de l'amnésie.")
                    display_text()
                    wait_for_click()


                    update_text("> Le joueur et Taro décidant de continuer à explorer ensemble avancent prudemment à travers l'usine.")
                    display_text()
                    wait_for_click()


                    update_text("> Leurs pas résonnent dans le silence oppressant chaque coin obscur dissimulant des mystères potentiellement dangereux.")
                    display_text()
                    wait_for_click()

                    update_text("> chaque coin obscur dissimulant des mystères potentiellement dangereux.")
                    display_text()
                    wait_for_click()

                    background_image = pygame.image.load("urnes.png")
                    background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                    # Set up the font
                    font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                    # Set up the text area
                    text_area_color = (0, 0, 0)
                    text_area_height = 140
                    text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                    # Draw everything
                    screen.blit(background_image, (0, 0))
                    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                    screen.fill(text_area_color, text_area_rect)

                    update_text("> Finalement, ils arrivent dans un laboratoire rempli d'urnes contenant un liquide noir et mystérieux.")
                    display_text()
                    pygame.mixer.music.stop()
                    pygame.mixer.music.load("usine.mp3")
                    pygame.mixer.music.play(-1)
                    wait_for_click()

                    SalleDangerTaro()
                    # Load image
                    background_image = pygame.image.load("Black.png")
                    background_image = pygame.transform.scale(background_image, (screen_width, screen_height))


                    # Set up the font
                    font = pygame.font.Font("VCR_OSD_MONO_1.001.ttf", 16)

                    # Set up the text area
                    text_area_color = (0, 0, 0)
                    text_area_height = 140
                    text_area_rect = pygame.Rect(20, 570, 1240, text_area_height)

                    # Draw everything
                    screen.blit(background_image, (0, 0))
                    pygame.draw.rect(screen, (255, 255, 255), (17, 567, 1246, 146), 3)
                    screen.fill(text_area_color, text_area_rect)

                    update_text("> To be continued...")
                    display_text()
                    pygame.mixer.music.stop()
                    pygame.quit()
                    sys.exit()

# ...
# Update the display
pygame.display.flip()

# Quit pygame
pygame.quit()